# Review bundle contents

This transport bundle contains the exact non-authoritative Release 2 D5
numerical-contract candidate review target.

- `BASE-COMMIT.txt` pins the comparison base.
- `REPOSITORY-COMMIT.txt` pins the review target.
- `REVIEW-PROMPT.md` defines the independent adversarial-review scope.
- `repository.gitbundle` contains the target branch and its reachable history.
- `repository/` is a byte-for-byte `git archive` of the pinned target commit.
- `MANIFEST.sha256` binds every other regular file in this bundle.

The bundle contains no private product-repository material and is not a Protocol
authority artifact. The adjacent ZIP and SHA-256 file are temporary review
transport only.
